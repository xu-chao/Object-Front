// headers.js

export const headers = {
    'Content-Type': 'application/json',
    // 可以添加其他通用的请求头字段
};
